1. FPHMC.html show illustration of the FPHMC method in the paper.  

2. FPHMC.Rmd file contains the R markdown code for the same.

3. Functions (source the source_multiz.R file for loading all the following functions)
Implements the FPHMC method as developed in the paper. 
Provided code currently supports functional covariate in both latency and cure part.
Easily extendable to implement other scenarios.

i) Wrapper function for using the FPHMC method
#@formula: Latency submodel as ~ as.formula(paste("Surv(time,status)~X+Xs"))
#@cureform: Cure submodel as ~ as.formula(paste("Surv(time,status)~X+Xs"))
#@offset: Offset, NULL as default
#@data: dataframe # with following objects
    #time= observed survival time
    #status= event indicator
    #X= scalar covariates for latency submodel n*p matrix
    #Xs= functional covariates for latency submodel on a grid n*m matrix
    #Z= scalar covariates for cure submodel n*p matrix
    #Zs= functional covariates for cure submodel on a grid n*m matrix
    #Smat= A n*m matrix of observed functional grid
#@model: Survival model (PH supported currently) 
#@link: Link function for cure submodel
#@Var: Whether to use Bootstrap for variance computation
#@emmax: Maximum number of iteration for EM algorithm
#@eps: Tolerance level for convergence
Use: smcureFUNC(formula=f1,cureform=f2,data=dat,model="ph",
                            Var = FALSE)
Value: 
#$b= cure parameter estimate
#$beta = latency parameter estimate
#$b_S = estimated functional coefficient cure model
#$beta_S = estimated functional coefficient latency model
#$s = estimated baseline survival function

ii) ##########Function for EM Algorithm##############
#@Time= observed survival time
#@status= event indicator
#@X= scalar covariates for latency submodel n*p matrix
#@Xs= functional covariates for latency submodel on a grid n*m matrix
#@Z= scalar covariates for cure submodel n*p matrix
#@Zs= functional covariates for cure submodel on a grid n*m matrix
#@Smat= A n*m matrix of observed functional grid
#@offsetvar: Offset
#@b= cure parameter estimate
#@beta = latency parameter estimate
#@b_S = estimated functional coefficient cure model
#@beta_S = estimated functional coefficient latency model
#@model: Survival model (PH supported currently) 
#@link: Ling function for cure submodel
#@emmax: Maximum number of iteration for EM algorithm
#@eps: Tolerance level for convergence
Use: emFUNC(Time,Status,X,Z,Xs,Zs,Smat,offsetvar,b,beta,b_S,beta_S,model,link,emmax,eps)

iii) ##########Function for estimating baseline survival function ##############
#@Time= observed survival time
#@status= event indicator
#@X= scalar covariates for latency submodel n*p matrix
#@beta = latency parameter estimate
#@Xs= functional covariates for latency submodel on a grid n*m matrix
#@beta_S = estimated functional coefficient latency model
#@Smat= A n*m matrix of observed functional grid
#@w: Weights calculated from the E step
#@model: Survival model (PH supported currently) 
Use: smsurvFUNC(Time,Status,X,beta,Xs,beta_S,Smat,w,model)


iv) ########## Function for prediction of survival function given covariates###########
#@object= Fitted smcureFUNC model
#@newX= New scalar covariates for latency submodel (n_0*p matrix)
#@newZ= New scalar covariates for cure submodel n*p matrix (n_0*p matrix)
#@newXs= New functional covariates for latency submodel on a grid (n_0*m matrix)
#@newZs= New functional covariates for cure submodel on a grid (n_0*m matrix)
#@model: Survival model (PH supported currently) 
Use: predictsmcureFUNC(object, newX, newZ,newXs,newZs, model = c("ph")) 

