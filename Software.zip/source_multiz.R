################Wrapper function for FPHMC method##############
#@formula: Latency submodel as ~ as.formula(paste("Surv(time,status)~X+Xs"))
#@cureform: Cure submodel as ~ as.formula(paste("Surv(time,status)~X+Xs"))
#@offset: Offset, NULL as default
#@data: dataframe # with following objects
    #time= observed survival time
    #status= event indicator
    #X= scalar covariates for latency submodel n*p matrix
    #Xs= functional covariates for latency submodel on a grid n*m matrix
    #Z= scalar covariates for cure submodel n*p matrix
    #Zs= functional covariates for cure submodel on a grid n*m matrix
    #Smat= A n*m matrix of observed functional grid
#@model: Survival model (PH supported currently) 
#@link: Link function for cure submodel
#@Var: Whether to use Bootstrap for variance computation
#@emmax: Maximum number of iteration for EM algorithm
#@eps: Tolerance level for convergence

smcureFUNC<-function (formula, cureform, offset = NULL, data, na.action = na.omit, 
                      model = c("ph"), link = "logit", 
                      Var = FALSE, emmax = 50, eps = 1e-07) 
{
  cat("Program is running..be patient...")
  data <- na.action(data)
  n <- dim(data)[1]
  Smat<-data$Smat
  m<-ncol(Smat)
  mf <- model.frame(formula, data)
  cvars <- all.vars(cureform)
  mfZ <- model.frame(cureform, data)
  mfZ$Intercept<-rep(1,n)
  
  if (!is.null(offset)) {
    offsetvar <- all.vars(offset)
    offsetvar <- data[, offsetvar]
  } else offsetvar <- NULL
  Y <- model.extract(mf, "response")
  
  if (!inherits(Y, "Surv")) 
    stop("Response must be a survival object")
  Time <- Y[, 1]
  Status <- Y[, 2]
  
  w <- Status
  library(mgcv)
  
  Zs_sc<-mfZ$Zs/m
  Z<-mfZ$Z
  
  bmod<-gam(w ~ Z+s(Smat,k=20,by=Zs_sc,bs="ps",m=2),family=quasibinomial())
  b<-as.numeric(bmod$coefficients[1:(ncol(Z)+1)])
  pdf(NULL)
  aa<-plot(bmod,n=m)
  invisible(dev.off())
  
  b_S<-as.numeric(aa[[1]]$fit)
  X<-mf$X
  Xs_sc<-mf$Xs/m
  if (model == "ph") 
    betamod<-gam(Time~X+s(Smat,k=20,by=Xs_sc,bs="ps",m=2)+ offset(log(w)),
                 family=cox.ph(),weights=Status,subset = w != 0)
  
  beta<-as.numeric(betamod$coefficients[1:ncol(X)]) 
  pdf(NULL)
  aa2<-plot(betamod,n=m)
  invisible(dev.off())
  
  beta_S<-as.numeric(aa2[[1]]$fit)
  
  
  Z<-cbind(rep(1,n),Z)
  Xs<-mf$Xs
  Zs<-mfZ$Zs
  emfit <-emFUNC(Time,Status,X,Z,Xs,Zs,Smat,offsetvar,b,beta,b_S,beta_S,model,link,emmax,eps) #em(Time, Status, X, Z, offsetvar, b, beta, model, 
  
  b <- emfit$b
  beta <- emfit$latencyfit
  s <- emfit$Survival
  b_S<-emfit$b_S
  beta_S<-emfit$beta_S
  logistfit <- emfit$logistfit
  fit <- list()
  
  fit$logistfit <- logistfit
  fit$b <- b
  fit$beta <- beta
  fit$s <- s
  fit$b_S <- b_S
  fit$beta_S <- beta_S
  cat(" done.\n")
  
  fit$Time <- Time
  
  fit
  
}

##########Function for EM Algorithm##############
#@Time= observed survival time
#@status= event indicator
#@X= scalar covariates for latency submodel n*p matrix
#@Xs= functional covariates for latency submodel on a grid n*m matrix
#@Z= scalar covariates for cure submodel n*p matrix
#@Zs= functional covariates for cure submodel on a grid n*m matrix
#@Smat= A n*m matrix of observed functional grid
#@offsetvar: Offset
#@b= cure parameter estimate
#@beta = latency parameter estimate
#@b_S = estimated functional coefficient cure model
#@beta_S = estimated functional coefficient latency model
#@model: Survival model (PH supported currently) 
#@link: Link function for cure submodel
#@emmax: Maximum number of iteration for EM algorithm
#@eps: Tolerance level for convergence

emFUNC <-
  function(Time,Status,X,Z,Xs,Zs,Smat,offsetvar,b,beta,b_S,beta_S,model,link,emmax,eps)
  {     
    w <- Status	
    n <- length(Status)
    m<-ncol(Xs)
    if(model == "ph") {s <- smsurvFUNC(Time,Status,X,beta,Xs,beta_S,Smat,w,model)$survival}
    
    convergence<- 1000;i <-1
    
    while (convergence > eps & i < emmax){  
      uncureprob <- matrix(exp((b)%*%t(Z)+as.numeric((1/m)*Zs%*%b_S))/(1+exp((b)%*%t(Z)+as.numeric((1/m)*Zs%*%b_S))),ncol=1)
      if(model == "ph"){
        survival<-drop(s^(exp((beta)%*%t(X)+as.numeric((1/m)*Xs%*%beta_S))))}
      
      ## E step 
      w <- Status+(1-Status)*(uncureprob*survival)/((1-uncureprob)+uncureprob*survival)
      ## M step (complete this onwards)
     
      Zs_sc<-Zs/m
      Xs_sc<-Xs/m
      
      logistfit<-gam(w ~ Z[,-1]+s(Smat,k=20,by=Zs_sc,bs="ps",m=2),family=quasibinomial())
      update_cureb<-as.numeric(logistfit$coefficients[1:ncol(Z)])
      pdf(NULL)
      temp<-plot(logistfit,n=m)
      invisible(dev.off())
      
      update_b_S<-as.numeric(temp[[1]]$fit)
      
      if(model == "ph") {
       
        betamod<-gam(Time~X+s(Smat,k=20,by=Xs_sc,bs="ps",m=2)+ offset(log(w)),
                     family=cox.ph(),weights=Status,subset = w != 0) ##
        
        update_beta <-as.numeric(betamod$coefficients[1:ncol(X)])  
        
        update_s <- smsurvFUNC(Time,Status,X,beta,Xs,beta_S,Smat,w,model)$survival
        pdf(NULL)
        temp<-plot(betamod,n=m)
        invisible(dev.off())
        
        update_beta_S<-as.numeric(temp[[1]]$fit)
      }
      
      convergence<-sum(c(update_cureb-b,update_beta-beta)^2)+sum((s-update_s)^2+mean((update_b_S-b_S)^2)+mean((update_beta_S-beta_S)^2))
      b <- update_cureb
      beta <- update_beta 
      b_S<-update_b_S
      beta_S<-update_beta_S
      s<-update_s
      uncureprob<- matrix(exp((b)%*%t(Z)+as.numeric((1/m)*Zs%*%b_S))/(1+exp((b)%*%t(Z)+as.numeric((1/m)*Zs%*%b_S))),ncol=1)
      i <- i+1
    }
    
    em <- list(logistfit=logistfit,b=b,b_S=b_S,latencyfit= beta,beta_S=beta_S,Survival=s,Uncureprob=uncureprob,tau=convergence)
  }
########## Function for estimation for baseline survival function###########
#@Time= observed survival time
#@status= event indicator
#@X= scalar covariates for latency submodel n*p matrix
#@beta = latency parameter estimate
#@Xs= functional covariates for latency submodel on a grid n*m matrix
#@beta_S = estimated functional coefficient latency model
#@Smat= A n*m matrix of observed functional grid
#@w: Weights calculated from the E step
#@model: Survival model (PH supported currently) 
smsurvFUNC <-function(Time,Status,X,beta,Xs,beta_S,Smat,w,model){    
  death_point <- sort(unique(subset(Time, Status==1)))
  m<-ncol(Xs)
  if(model=='ph') coxexp <- exp(as.numeric((beta)%*%t(X))+as.numeric((1/m)*Xs%*%beta_S))  
  lambda <- numeric()
  event <- numeric()
  for(i in 1: length(death_point)){
    event[i] <- sum(Status*as.numeric(Time==death_point[i]))
    if(model=='ph')  temp <- sum(as.numeric(Time>=death_point[i])*w*drop(coxexp))
    temp1 <- event[i]
    lambda[i] <- temp1/temp
  }
  HHazard <- numeric()
  for(i in 1:length(Time)){
    HHazard[i] <- sum(as.numeric(Time[i]>=death_point)*lambda)
    if(Time[i]>max(death_point))HHazard[i] <- Inf
    if(Time[i]<min(death_point))HHazard[i] <- 0
  }
  survival <- exp(-HHazard)
  list(survival=survival)
}

########## Function for prediction of survival function given covariates###########
#@object= Fitted smcureFUNC model
#@newX= New scalar covariates for latency submodel (n_0*p matrix)
#@newZ= New scalar covariates for cure submodel n*p matrix (n_0*p matrix)
#@newXs= New functional covariates for latency submodel on a grid (n_0*m matrix)
#@newZs= New functional covariates for cure submodel on a grid (n_0*m matrix)
#@model: Survival model (PH supported currently) 

predictsmcureFUNC<-function (object, newX, newZ,newXs,newZs, model = c("ph"), 
          ...) 
{
  #call <- match.call()
  #if (!inherits(object, "smcure")) 
  #  stop("Object must be results of smcure")
  if (is.vector(newZ)) 
    newZ = as.matrix(newZ)
  newZ = cbind(1, newZ)
  if (is.vector(newX)) 
    newX = as.matrix(newX)
  s0 = as.matrix(object$s, ncol = 1)
  n = nrow(s0)
  m=length(object$b_S)
  uncureprob =  matrix(exp((object$b)%*%t(newZ)+as.numeric((1/m)*newZs%*%object$b_S))/(1+exp((object$b)%*%t(newZ)+as.numeric((1/m)*newZs%*%object$b_S))),ncol=1)
  scure = array(0, dim = c(n, nrow(newX)))
  t = array(0, dim = c(n, nrow(newX)))
  spop = array(0, dim = c(n, nrow(newX)))
  if (model == "ph") {
    ebetaX = exp(object$beta %*% t(newX)+as.numeric((1/m)*newXs%*%object$beta_S))
    for (i in 1:nrow(newZ)) {
      scure[, i] = s0^ebetaX[i]
    }
    for (i in 1:n) {
      for (j in 1:nrow(newX)) {
        spop[i, j] = uncureprob[j] * scure[i, j] + (1 - 
                                                      uncureprob[j])
      }
    }
    prd = cbind(spop, Time = object$Time)
  }
 
  structure(list(newuncureprob = uncureprob, prediction = prd), 
            class = "predictsmcureFUNC")
}

#S_{pop}(t)=π+(1-π)*S(t)